from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage

from easy_sqlite3 import EasySQLite3


database = EasySQLite3()
database.connect(path='db/database.db')

token = '5881394175:AAHdyhYa-K1Qzv2zmVn-aBrqEBU9AQaSnXs'

owners = [5386754994]
chat_id = -1001826943043 


bot = Bot(token=token, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot, storage=MemoryStorage())