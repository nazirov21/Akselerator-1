from aiogram import types, Dispatcher
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher import FSMContext
import time

from States.state_log_in import StateLogIn
from CONFIG import database, bot, chat_id


async def log_in_account(message: types.Message):
    await message.answer('Для входа в учетную запись, напишите свой идентификационный номер')
    await StateLogIn.id_emp.set()


async def input_id_user_in(message: types.Message, state: FSMContext):
    id_emp = int(message.text)
    await state.update_data(id_emp=id_emp)
    check_emp = database.check_value(query=f'SELECT * FROM employees WHERE id = {id_emp}')
    if check_emp:
        await message.answer('Введите свой пароль')
        return await StateLogIn.next()
    await message.answer('Такого пользователя не существует!')
    await state.finish()


async def input_password_in(message: types.Message, state: FSMContext):
    password = int(message.text)
    data = await state.get_data()
    check_emp = database.select(query=f'SELECT * FROM employees WHERE id = {data["id_emp"]}', fetch='one')
    await state.update_data(password=password)
    if check_emp[2] == password:
        t = time.localtime()
        current_time = time.strftime('%H:%M:%S', t)
        await message.answer(f'{check_emp[1]}, здравствуйте. Вы вошли в свой аккаунт!')
        await bot.send_message(chat_id, f'Пользователь <b>{check_emp[1]}</b> зашел в свой аккаунт в {current_time}!')
        return await state.finish()
    await message.answer('Неверный пароль! Повторите попытку входа.')
    await state.finish()



def log_in(dsp: Dispatcher):
    dsp.register_message_handler(log_in_account, Command(['log_in'], prefixes='!/.', ignore_case=True))
    dsp.register_message_handler(input_id_user_in, state=StateLogIn.id_emp)
    dsp.register_message_handler(input_password_in, state=StateLogIn.password)
