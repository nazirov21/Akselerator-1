from aiogram import types, Dispatcher
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher import FSMContext
import random

from States.state_add_emp import StateAddEmp
from States.state_del_emp import StateDelEmp
from CONFIG import owners, database


async def add_employee(message: types.Message):
    if message.from_id not in owners:
        return await message.answer('У вас недостаточно прав.')
    await message.answer('Для создания пользователя, напишите его имя')
    await StateAddEmp.name.set()


async def create_employee(message: types.Message, state: FSMContext):
    await state.finish()
    ids = database.select(query='SELECT count(*) FROM employees', fetch='one')[0]
    name = message.text
    gen_password = ''.join(map(str, random.choices(list(range(10)), k=5)))
    id_emp = ids + 1
    database.insert_into(query=f'INSERT INTO employees VALUES ({id_emp}, "{name}", {gen_password})')
    await message.answer(f'Идентификационный номер: <code>{id_emp}</code>\n'+
                         f'Имя пользователя: <code>{name}</code>\n'+
                         f'Пароль: <code>{gen_password}</code>\n\n'+
                         f'Перешлите это сообщение добавленному пользователя.')


async def input_del_employee(message: types.Message):
    if message.from_id not in owners:
        return await message.answer('У вас недостаточно прав.')
    await message.answer('Для удаления пользователя, напишите его идентификационный номер')
    await StateDelEmp.id_emp.set()


async def del_employee(message: types.Message, state: FSMContext):
    await state.finish()
    id = int(message.text)
    check_emp = database.check_value(query=f'SELECT * FROM employees WHERE id = {id}')
    if check_emp:
        database.delete(query=f'DELETE FROM employees WHERE id = {id}')
        return await message.answer('Вы удалили пользователя!')
    await message.answer('Такого пользователя не существует!')


async def help_command(message: types.Message):
    if message.from_id not in owners:
        return await message.answer('У вас недостаточно прав.')
    await message.answer(f'<b>Команды:</b>\n\n'+
                         f'/add_epm\n'+
                         f'/del_emp\n'+
                         f'/log_in\n'+
                         f'/log_out')


def administarive_commands(dsp: Dispatcher):
    dsp.register_message_handler(add_employee, Command(['add_emp'], prefixes='!/.', ignore_case=True))
    dsp.register_message_handler(create_employee, state=StateAddEmp.name)

    dsp.register_message_handler(input_del_employee, Command(['del_emp'], prefixes='!/.', ignore_case=True))
    dsp.register_message_handler(del_employee, state=StateDelEmp.id_emp)

    dsp.register_message_handler(help_command, Command(['help'], prefixes='!/.', ignore_case=True))
