from aiogram import types, Dispatcher
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher import FSMContext
import time

from States.state_log_out import StateLogOut
from CONFIG import database, bot, chat_id


async def log_out_account(message: types.Message):
    await message.answer('Для выхода из учетной записи, напишите свой идентификационный номер')
    await StateLogOut.id_emp.set()


async def input_id_user_out(message: types.Message, state: FSMContext):
    await state.finish()
    id_emp = int(message.text)
    check_emp = database.select(f'SELECT * FROM employees WHERE id = {id_emp}', fetch='one')
    if check_emp is not None:
        t = time.localtime()
        current_time = time.strftime('%H:%M:%S', t)
        await message.answer('Вы вышли из своей учетной записи!')
        return await bot.send_message(chat_id, f'Пользователь <b>{check_emp[1]}</b> вышел из своего аккаунта в {current_time}!')
    await message.answer('Такого пользователя не существует!')
    



def log_out(dsp: Dispatcher):
    dsp.register_message_handler(log_out_account, Command(['log_out'], prefixes='!/.', ignore_case=True))
    dsp.register_message_handler(input_id_user_out, state=StateLogOut.id_emp)
