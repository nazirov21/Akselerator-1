from aiogram.utils import executor

from CONFIG import dp
from handlers import log_in, log_out, administrative_commands


administrative_commands.administarive_commands(dp)
log_in.log_in(dp)
log_out.log_out(dp)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
