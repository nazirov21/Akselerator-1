from aiogram.dispatcher.filters.state import StatesGroup, State


class StateAddEmp(StatesGroup):
    name = State()