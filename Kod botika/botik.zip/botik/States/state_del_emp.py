from aiogram.dispatcher.filters.state import StatesGroup, State


class StateDelEmp(StatesGroup):
    id_emp = State()